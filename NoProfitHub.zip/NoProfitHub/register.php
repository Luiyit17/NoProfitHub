<?php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo = $_POST['tipo'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Verifica se l'email esiste già
    $check = $conn->prepare("SELECT id FROM utenti WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "<script>alert('Email già registrata');</script>";
    } else {
        // Inserimento
        $stmt = $conn->prepare("INSERT INTO utenti (tipo, nome, email, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $tipo, $nome, $email, $password);
        $stmt->execute();

        echo "<script>alert('Registrazione completata'); window.location.href='login.php';</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Registrazione - NoProfitHub</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:rgb(0, 204, 255);
             background-image: url(logo1.jpg);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 570px;
             width: 1500px;
            
        }
        form {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
            width: 350px;
        }
        h2 {
            margin-bottom: 20px;
            color: #2c3e50;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            width: 100%;
            background-color: #27ae60;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        button:hover {
            background-color: #219150;
        }
    </style>
</head>
<body>
    <form action="register.php" method="POST">
        <h2>Registrazione</h2>

        <label for="tipo">Tipo utente:</label>
        <select name="tipo" id="tipo" required>
            <option value="volontario">Volontario</option>
            <option value="associazione">Associazione</option>
        </select>

        <label for="nome">Nome / Nome Associazione:</label>
        <input type="text" name="nome" required>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <button type="submit">Registrati</button>
    </form>
</body>
</html>
