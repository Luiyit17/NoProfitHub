<?php
session_start();
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, nome, tipo, password FROM utenti WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $nome, $tipo, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['id'] = $id;
            $_SESSION['nome'] = $nome;
            $_SESSION['tipo'] = $tipo;

            // Reindirizza in base al tipo utente
       
           if ($tipo == 'volontario') {
                header("Location: users/volontario/volontario_dashboard.php");
            } elseif ($tipo == 'associazione') {
                header("Location: users/associazione/associazione_dashboard.php");
            } elseif ($tipo == 'admin') {
                header("Location: users/admin/admin_dashboard.php");
            }
            exit();

        } else {
            echo "<script>alert('Password errata');</script>";
        }
    } else {
        echo "<script>alert('Utente non trovato');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Login - NoProfitHub</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            background-image: url(logo1.jpg);

            display: flex;
            justify-content: center;
            align-items: center;
            
        }
        form {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
            width: 350px;
        }
        h2 {
            margin-bottom: 20px;
            color: #2c3e50;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            width: 100%;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        button:hover {
            background-color: #21618c;
        }
    </style>
</head>
<body>
    <form action="login.php" method="POST">
        <h2>Accedi</h2>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <button type="submit">Accedi</button>
    </form>
</body>
</html>
