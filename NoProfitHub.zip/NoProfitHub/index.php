<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>NoProfitHub</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            background-image: URL(logo1.jpg);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
 
        }
        .container {
            text-align: center;
            height: 200PX;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        p {
            color: #555;
            margin-bottom: 30px;
        }
        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 16px;
            background-color: #27ae60;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #1e8449;
        }
    </style>
</head>
<body>
    
    <div class="container" style="position: relative; top: 40px;">
        </img>
        <h1>La piattaforma digitale per connettere volontari, associazioni e progetti sociali.<br></h1>
        <h4>Qui potrai: gestire turni, attestati, partecipazioni e report in un unico spazio.</h4>

        <a class="btn" href="login.php">Accedi</a>
        <a class="btn" href="register.php">Registrati</a>
    </div>
</body>
</html>
