<?php
session_start();
require_once '../../db.php'; // corretto path per db.php

// ✅ Solo volontari loggati possono accedere
if (!isset($_SESSION['id']) || $_SESSION['tipo'] !== 'volontario') {
    header("Location: ../../login.php");
    exit();
}

$id_volontario = $_SESSION['id'];
$id_progetto = isset($_GET['id_progetto']) ? intval($_GET['id_progetto']) : 0;

// ❌ ID progetto mancante o non valido
if ($id_progetto <= 0) {
    echo "<script>alert('Progetto non valido.'); window.location.href='volontario_dashboard.php';</script>";
    exit();
}

// ✅ Verifica se il progetto esiste
$stmt = $conn->prepare("SELECT id FROM progetti WHERE id = ?");
$stmt->bind_param("i", $id_progetto);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "<script>alert('Progetto non trovato.'); window.location.href='volontario_dashboard.php';</script>";
    exit();
}
$stmt->close();

// ✅ Verifica se il volontario è già iscritto
$check = $conn->prepare("SELECT id FROM iscrizioni WHERE id_progetto = ? AND id_volontario = ?");
$check->bind_param("ii", $id_progetto, $id_volontario);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "<script>alert('Sei già iscritto a questo progetto.'); window.location.href='volontario_dashboard.php';</script>";
    exit();
}
$check->close();

// ✅ Inserisci l'iscrizione
$insert = $conn->prepare("INSERT INTO iscrizioni (id_progetto, id_volontario) VALUES (?, ?)");
$insert->bind_param("ii", $id_progetto, $id_volontario);
if ($insert->execute()) {
    echo "<script>alert('Iscrizione completata con successo!'); window.location.href='volontario_dashboard.php';</script>";
    // Dopo inserimento iscrizione...
mail($row['assoc_email'], "Nuova candidatura per '$row[titolo]'", 
  "Ciao $row[assoc_nome],\n\nHai ricevuto una nuova candidatura per il progetto '$row[titolo]'. Accedi alla dashboard per gestirla.\n\nNoProfitHub"
);

} else {
    echo "<script>alert('Errore durante l\'iscrizione. Riprova.'); window.location.href='volontario_dashboard.php';</script>";
}
$insert->close();



?>
