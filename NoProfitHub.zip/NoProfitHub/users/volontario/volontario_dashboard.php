<?php
require_once '../../db.php';
require_once '../../includes/auth_check.php';

if ($_SESSION['tipo'] != 'volontario') {
    header("Location: ../login.php");
    exit();
}

$id_volontario = $_SESSION['id'];
$nome = $_SESSION['nome'];

// --- CARICAMENTO DATI UTENTE ---

// Competenze predefinite
$res_competenze_predefinite = $conn->query("SELECT * FROM competenze_predefinite");

// Competenze selezionate dal volontario
$res_competenze_volontario = $conn->query("SELECT id_competenza FROM volontario_competenze WHERE id_volontario = $id_volontario");
$competenze_selezionate = array_column($res_competenze_volontario->fetch_all(MYSQLI_ASSOC), 'id_competenza');

// Disponibilità utente come array (da tabella disponibilita_volontario)
$disponibilita_selezionata = [];
$res_disp = $conn->prepare("SELECT giorno, fascia_oraria FROM disponibilita_volontario WHERE id_volontario = ?");
$res_disp->bind_param("i", $id_volontario);
$res_disp->execute();
$res_disp->bind_result($giorno, $fascia);
while ($res_disp->fetch()) {
    $disponibilita_selezionata[] = $giorno . '_' . strtolower($fascia);
}
$res_disp->close();

// --- SALVATAGGIO PROFILO (POST) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $competenze_post = isset($_POST['competenze']) ? $_POST['competenze'] : [];
    $disponibilita_post = isset($_POST['disponibilita']) ? $_POST['disponibilita'] : [];

    // Aggiorna disponibilità (tabella disponibilita_volontario)
    $stmt_del_disp = $conn->prepare("DELETE FROM disponibilita_volontario WHERE id_volontario = ?");
    $stmt_del_disp->bind_param("i", $id_volontario);
    $stmt_del_disp->execute();

    if (!empty($disponibilita_post)) {
        $stmt_ins_disp = $conn->prepare("INSERT INTO disponibilita_volontario (id_volontario, giorno, fascia_oraria) VALUES (?, ?, ?)");
        foreach ($disponibilita_post as $disp) {
            $parts = explode('_', $disp, 2);
            if (count($parts) == 2) {
                $giorno = $parts[0];
                $fascia = ucfirst($parts[1]); // Mattina, Pomeriggio, Sera
                $stmt_ins_disp->bind_param("iss", $id_volontario, $giorno, $fascia);
                $stmt_ins_disp->execute();
            }
        }
        $stmt_ins_disp->close();
    }

    // Aggiorna competenze (tabella volontario_competenze)
    $stmt_del = $conn->prepare("DELETE FROM volontario_competenze WHERE id_volontario = ?");
    $stmt_del->bind_param("i", $id_volontario);
    $stmt_del->execute();

    if (!empty($competenze_post)) {
        $stmt_ins = $conn->prepare("INSERT INTO volontario_competenze (id_volontario, id_competenza) VALUES (?, ?)");
        foreach ($competenze_post as $comp) {
            $comp_int = intval($comp);
            $stmt_ins->bind_param("ii", $id_volontario, $comp_int);
            $stmt_ins->execute();
        }
        $stmt_ins->close();
    }

    // Ricarica dati aggiornati per visualizzazione form dopo submit
    $competenze_selezionate = $competenze_post;
    $disponibilita_selezionata = $disponibilita_post;
}

// --- CARICAMENTO PROGETTI DISPONIBILI FILTRATI ---

if (count($competenze_selezionate) > 0) {
    $ids_str = implode(',', array_map('intval', $competenze_selezionate));
    $sql_progetti = "
        SELECT DISTINCT p.*, u.nome AS nome_associazione 
        FROM progetti p
        JOIN progetto_competenze pc ON p.id = pc.id_progetto
        JOIN utenti u ON p.id_associazione = u.id
        WHERE pc.id_competenza IN ($ids_str)
        ORDER BY p.data_inizio DESC
    ";
} else {
    // Se nessuna competenza selezionata, mostra tutti i progetti
    $sql_progetti = "
        SELECT p.*, u.nome AS nome_associazione
        FROM progetti p
        JOIN utenti u ON p.id_associazione = u.id
        ORDER BY p.data_inizio DESC
    ";
}


// Recupera gli ID dei progetti a cui l'utente è già iscritto
$ids_iscritti = [];
$res_ids = $conn->query("SELECT id_progetto FROM iscrizioni WHERE id_volontario = $id_volontario");
while ($row = $res_ids->fetch_assoc()) {
    $ids_iscritti[] = $row['id_progetto'];
}


// Filtra i progetti disponibili escludendo quelli a cui l'utente è già iscritto
if (count($ids_iscritti) > 0) {
    $ids_str_esc = implode(',', array_map('intval', $ids_iscritti));
    // Se la query contiene già WHERE, aggiungi AND, altrimenti aggiungi WHERE
    if (strpos($sql_progetti, 'WHERE') !== false) {
        $sql_progetti = preg_replace('/ORDER BY/i', "AND p.id NOT IN ($ids_str_esc) ORDER BY", $sql_progetti, 1);
    } else {
        $sql_progetti = preg_replace('/ORDER BY/i', "WHERE p.id NOT IN ($ids_str_esc) ORDER BY", $sql_progetti, 1);
    }
}

$progetti = $conn->query($sql_progetti);

// --- STATO DELLE CANDIDATURE ---
$candidature = $conn->query("
    SELECT p.*, u.nome AS nome_associazione, i.stato
    FROM iscrizioni i
    JOIN progetti p ON i.id_progetto = p.id
    JOIN utenti u ON p.id_associazione = u.id
    WHERE i.id_volontario = $id_volontario
    ORDER BY p.data_inizio DESC
");

// --- ATTENDATI ---
$attestati = $conn->query("
    SELECT a.data_rilascio, a.descrizione, a.file_attestato, p.titolo 
    FROM attestati a
    JOIN progetti p ON a.id_progetto = p.id
    WHERE a.id_volontario = $id_volontario
    ORDER BY a.data_rilascio DESC
");

// --- TURNI E ORE TOTALI ---
$turni = $conn->query("
    SELECT t.data_turno, t.ore, p.titolo AS progetto, u.nome AS associazione
    FROM turni t
    JOIN progetti p ON t.id_progetto = p.id
    JOIN utenti u ON p.id_associazione = u.id
    WHERE t.id_volontario = $id_volontario
    ORDER BY t.data_turno ASC
");
$ore_totali = 0;
while ($t = $turni->fetch_assoc()) {
    $ore_totali += $t['ore'];
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8" />
<title>Dashboard Volontario - NoProfitHub</title>
<style>
body { font-family: Arial, sans-serif; background: #f3f6f9; padding: 20px; }
.container { max-width: 1000px; margin: auto; }
.topbar {
    text-align: right;
    margin-bottom: 30px;
}
.topbar span {
    font-weight: bold;
    margin-right: 20px;
}
.btn-logout {
    background: #c0392b;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.9rem;
}
.btn-logout:hover {
    background: #962d22;
}
h2 { color: #2c3e50; margin-bottom: 10px; }
form { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 8px rgba(0,0,0,0.1); margin-bottom: 40px; }
fieldset { border: none; margin-bottom: 20px; }
label.checkbox-btn {
    display: inline-block;
    margin: 5px 10px 5px 0;
    padding: 8px 15px;
    background: #eee;
    border-radius: 20px;
    cursor: pointer;
    user-select: none;
    transition: background-color 0.3s;
    border: 1px solid #ccc;
    font-size: 0.9rem;
}
label.checkbox-btn:hover {
    background-color: #d0eaff;
}
input[type="checkbox"] {
    display: none;
}
input[type="checkbox"]:checked + label.checkbox-btn {
    background-color: #3498db;
    color: white;
    border-color: #2980b9;
}
.btn-save {
    background: #2980b9;
    color: white;
    padding: 10px 18px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 1rem;
}
.btn-save:hover {
    background: #21618c;
}
.progetto {
    background-color: #fff;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
    box-shadow: 0 0 8px rgba(0,0,0,0.05);
}
.progetto h3 {
    margin: 0 0 10px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 40px;
    background: #fff;
}
table th, table td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
}
table th {
    background-color: #3498db;
    color: white;
}
</style>
</head>
<body>
<div class="container">

    <div class="topbar">
        <span>Benvenuto, <?php echo htmlspecialchars($nome); ?></span>
        <form style="display:inline" action="../../logout.php" method="post">
            <button class="btn-logout" type="submit">Esci</button>
        </form>
    </div>

    <h2>Modifica profilo</h2>
    <form method="post" action="">
        <fieldset>
            <legend>Competenze (seleziona una o più):</legend>
            <?php
            // Reset pointer of competenze_predefinite per sicurezza (permette riuso)
            $res_competenze_predefinite->data_seek(0);
            while ($row = $res_competenze_predefinite->fetch_assoc()):
                $checked = in_array($row['id'], $competenze_selezionate) ? 'checked' : '';
            ?>
                <input type="checkbox" id="comp_<?php echo $row['id']; ?>" name="competenze[]" value="<?php echo $row['id']; ?>" <?php echo $checked; ?> />
                <label class="checkbox-btn" for="comp_<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['nome']); ?></label>
            <?php endwhile; ?>
        </fieldset>

        <fieldset>
            <legend>Disponibilità (seleziona giorni e fasce orarie):</legend>
            <?php
            // Giorni + fasce orarie
            $giorni = ['lun', 'mar', 'mer', 'gio', 'ven', 'sab', 'dom'];
            $giorni_label = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
            $fasce = ['Mattina', 'Pomeriggio', 'Sera'];

            foreach ($giorni as $idx => $g) {
                echo "<div style='margin-bottom:12px;'>";
                echo "<strong>".$giorni_label[$idx].": </strong> ";
                foreach ($fasce as $f) {
                    $val = $g . "_" . strtolower($f); // esempio lun_mattina
                    $checked = in_array($val, $disponibilita_selezionata) ? 'checked' : '';
                    echo '<input type="checkbox" id="disp_'.$val.'" name="disponibilita[]" value="'.$val.'" '.$checked.' />';
                    echo '<label class="checkbox-btn" for="disp_'.$val.'">'.$f.'</label>';
                }
                echo "</div>";
            }
            ?>
        </fieldset>

        <button type="submit" class="btn-save">Salva modifiche</button>
    </form>


    <h2>Stato delle candidature</h2>
    <?php if ($candidature->num_rows > 0): ?>
        <?php while ($p = $candidature->fetch_assoc()): ?>
            <div class="progetto">
                <h3><?php echo htmlspecialchars($p['titolo']); ?></h3>
                <p><strong>Associazione:</strong> <?php echo htmlspecialchars($p['nome_associazione']); ?></p>
                <p><strong>Data inizio:</strong> <?php echo htmlspecialchars($p['data_inizio']); ?></p>
                <p><?php echo nl2br(htmlspecialchars($p['descrizione'])); ?></p>
                <p><strong>Stato candidatura:</strong> 
                    <?php 
                        if ($p['stato'] === 'accettato') {
                            echo '<span style="color:green;font-weight:bold">Accettato</span>';
                        } elseif ($p['stato'] === 'rifiutato') {
                            echo '<span style="color:red;font-weight:bold">Rifiutato</span>';
                        } else {
                            echo '<span style="color:#e67e22;font-weight:bold">In attesa</span>';
                        }
                    ?>
                </p>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>Non hai ancora inviato candidature a progetti.</p>
    <?php endif; ?>

    <h2>Progetti disponibili</h2>
    <?php if ($progetti->num_rows > 0): ?>
        <?php while ($p = $progetti->fetch_assoc()): ?>
            <div class="progetto">
                <h3><?php echo htmlspecialchars($p['titolo']); ?></h3>
                <p><strong>Associazione:</strong> <?php echo htmlspecialchars($p['nome_associazione']); ?></p>
                <p><strong>Data inizio:</strong> <?php echo htmlspecialchars($p['data_inizio']); ?></p>
                <p><?php echo nl2br(htmlspecialchars($p['descrizione'])); ?></p>
                <a class="btn" href="iscriviti.php?id_progetto=<?php echo $p['id']; ?>">Candidati</a>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>Nessun progetto disponibile al momento.</p>
    <?php endif; ?>

    <h2>Attestati ricevuti</h2>
    <?php if ($attestati->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Data rilascio</th>
                    <th>Progetto</th>
                    <th>Descrizione</th>
                    <th>File</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($a = $attestati->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($a['data_rilascio']); ?></td>
                    <td><?php echo htmlspecialchars($a['titolo']); ?></td>
                    <td><?php echo htmlspecialchars($a['descrizione']); ?></td>
                    <td>
                        <?php if (!empty($a['file_attestato'])): ?>
                            <a href="../../uploads/attestati/<?php echo urlencode($a['file_attestato']); ?>" target="_blank">Scarica</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Non hai ancora ricevuto attestati.</p>
    <?php endif; ?>

    <h2>Turni e ore totali</h2>
    <p>Ore totali svolte: <strong><?php echo $ore_totali; ?></strong></p>
    <?php if ($turni->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Data turno</th>
                    <th>Progetto</th>
                    <th>Associazione</th>
                    <th>Ore</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Riporta i turni dopo aver calcolato ore totali
                $turni->data_seek(0);
                while ($t = $turni->fetch_assoc()):
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($t['data_turno']); ?></td>
                    <td><?php echo htmlspecialchars($t['progetto']); ?></td>
                    <td><?php echo htmlspecialchars($t['associazione']); ?></td>
                    <td><?php echo htmlspecialchars($t['ore']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Non hai turni assegnati.</p>
    <?php endif; ?>

</div>
</body>
</html>
