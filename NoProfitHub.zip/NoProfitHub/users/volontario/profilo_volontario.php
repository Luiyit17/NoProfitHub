<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['id']) || $_SESSION['tipo'] !== 'volontario') {
    header("Location: ../../login.php");
    exit();
}

$id_volontario = $_SESSION['id'];

// Salvataggio dati
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Competenze
    $conn->query("DELETE FROM volontario_competenze WHERE id_volontario = $id_volontario");
    if (isset($_POST['competenze'])) {
        foreach ($_POST['competenze'] as $id_comp) {
            $stmt = $conn->prepare("INSERT INTO volontario_competenze (id_volontario, id_competenza) VALUES (?, ?)");
            $stmt->bind_param("ii", $id_volontario, $id_comp);
            $stmt->execute();
        }
    }

    // Disponibilità
    $conn->query("DELETE FROM disponibilita_volontario WHERE id_volontario = $id_volontario");
    if (isset($_POST['disponibilita'])) {
        foreach ($_POST['disponibilita'] as $item) {
            list($id_giorno, $id_fascia) = explode('_', $item);
            $stmt = $conn->prepare("INSERT INTO disponibilita_volontario (id_volontario, id_giorno, id_fascia) VALUES (?, ?, ?)");
            $stmt->bind_param("iii", $id_volontario, $id_giorno, $id_fascia);
            $stmt->execute();
        }
    }
}

// Recupero competenze disponibili
$competenze = $conn->query("SELECT * FROM competenze")->fetch_all(MYSQLI_ASSOC);

// Recupero giorni e fasce
$giorni = $conn->query("SELECT * FROM giorni")->fetch_all(MYSQLI_ASSOC);
$fasce = $conn->query("SELECT * FROM fasce_orarie")->fetch_all(MYSQLI_ASSOC);

// Competenze già selezionate
$scelte = $conn->query("SELECT id_competenza FROM volontario_competenze WHERE id_volontario = $id_volontario")->fetch_all(MYSQLI_ASSOC);
$scelte_comp = array_column($scelte, 'id_competenza');

// Disponibilità già selezionata
$scelte_disp = $conn->query("SELECT CONCAT(id_giorno, '_', id_fascia) as code FROM disponibilita_volontario WHERE id_volontario = $id_volontario")->fetch_all(MYSQLI_ASSOC);
$scelte_codici = array_column($scelte_disp, 'code');
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Profilo Volontario</title>
    <style>
        body { font-family: Arial; background: #f0f0f0; padding: 30px; }
        form { background: white; padding: 20px; border-radius: 8px; width: 600px; margin: auto; }
        select, textarea, input[type=text], label, .giorno-box { display: block; margin-top: 10px; }
        button { margin-top: 20px; padding: 10px; background-color: #2ecc71; color: white; border: none; border-radius: 5px; }
    </style>
</head>
<body>
    <form method="POST">
        <h2>Profilo Volontario</h2>

        <label>Competenze (seleziona più di una):</label>
        <select name="competenze[]" multiple required>
            <?php foreach ($competenze as $c): ?>
                <option value="<?= $c['id'] ?>" <?= in_array($c['id'], $scelte_comp) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($c['nome']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Disponibilità settimanale:</label>
        <?php foreach ($giorni as $g): ?>
            <div class="giorno-box">
                <strong><?= $g['nome'] ?>:</strong><br>
                <?php foreach ($fasce as $f): 
                    $code = $g['id'] . "_" . $f['id'];
                ?>
                    <label>
                        <input type="checkbox" name="disponibilita[]" value="<?= $code ?>" <?= in_array($code, $scelte_codici) ? 'checked' : '' ?>>
                        <?= $f['nome'] ?>
                    </label>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>

        <button type="submit">Salva</button>
        <a class="btn" href="volontario_dashboard.php">Torna alla dashboard</a>
    </form>
</body>
</html>
