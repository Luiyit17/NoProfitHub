<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['id']) || $_SESSION['tipo'] !== 'associazione') {
    header("Location: ../login.php");
    exit();
}

$id_associazione = $_SESSION['id'];

// Progetti esistenti
$progetti = $conn->query("SELECT * FROM progetti WHERE id_associazione = $id_associazione");

// Report ore
$report = $conn->query("
    SELECT p.titolo, SUM(t.ore) AS tot_ore
    FROM turni t
    JOIN progetti p ON t.id_progetto = p.id
    WHERE p.id_associazione = $id_associazione
    GROUP BY p.id
");

// Candidature in attesa
$candidature = $conn->query("
    SELECT i.id, i.id_volontario, u.nome, u.email, p.id AS id_progetto, p.titolo
    FROM iscrizioni i
    JOIN utenti u ON i.id_volontario = u.id
    JOIN progetti p ON i.id_progetto = p.id
    WHERE p.id_associazione = $id_associazione AND i.stato = 'in_attesa'
");

// Volontari accettati
$accettati = $conn->query("
    SELECT u.nome, p.titolo
    FROM iscrizioni i
    JOIN utenti u ON i.id_volontario = u.id
    JOIN progetti p ON i.id_progetto = p.id
    WHERE p.id_associazione = $id_associazione AND i.stato = 'accettato'
");

// Matching automatico: trova volontari compatibili per ogni progetto
$matching = $conn->query("
    SELECT v.id, v.nome, p.titolo, p.id AS id_progetto
    FROM utenti v
    JOIN progetti p ON p.id_associazione = $id_associazione
    WHERE v.tipo = 'volontario'
    AND NOT EXISTS (
        SELECT 1 FROM iscrizioni i WHERE i.id_volontario = v.id AND i.id_progetto = p.id
    )
    AND (
        SELECT COUNT(*) FROM volontario_competenze cv
        JOIN progetto_competenze rp ON rp.id_competenza = cv.id_competenza
        WHERE cv.id_volontario = v.id AND rp.id_progetto = p.id
    ) > 0
");
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Associazione</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f6f9;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
        }
        h2 {
            color: #2c3e50;
        }
        .blocco1 {
            background-color: #fff;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
        }
        .btn {
            margin: 5px 5px 0 0;
            display: inline-block;
            background-color: #2980b9;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #21618c;
        }
        .btn-danger {
            background-color: #c0392b;
        }
        .topbar {
            text-align: right;
            margin-bottom: 30px;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            margin-left: 5px;
        }
        .badge-attesa { background: #f1c40f; color: white; }
        .badge-accettato { background: #27ae60; color: white; }
        .badge-rifiutato { background: #e74c3c; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <div class="topbar">
            <span>Benvenuto</span>
            <a class="btn" href="../../logout.php">Esci</a>
        </div>

        <h2>Crea Nuovo Progetto</h2>
        <a class="btn" href="crea_progetto.php">➕ Crea nuovo progetto</a>

        <h2>I tuoi Progetti</h2>
        <div class="blocco1">
            <?php while ($p = $progetti->fetch_assoc()): ?>
                <div style="border:1px solid #ccc; margin:10px; padding:10px;">
                    <strong>Nome Progetto:</strong><strong><?= htmlspecialchars($p['titolo']) ?></strong><br>
                    <strong>Descrizione:</strong> <?= htmlspecialchars($p['descrizione']) ?><br>
                    <strong>Data Inizio:</strong> <?= htmlspecialchars($p['data_inizio']) ?><br>
                    <strong>Data Fine:</strong> <?= htmlspecialchars($p['data_fine']) ?><br>

                    <a class="btn" href="modifica_progetto.php?id=<?= $p['id'] ?>">Modifica</a>
                    <a class="btn" href="elimina_progetto.php?id=<?= $p['id'] ?>">Elimina</a>
                    <a class="btn" href="gestione_turni.php?id_progetto=<?= $p['id'] ?>">Gestisci Turni</a>
                    <a class="btn" href="genera_attestati.php?id_progetto=<?= $p['id'] ?>">Genera Attestato</a>
                    <a class="btn" href="volontari_progetto.php?id=<?= $p['id'] ?>">Volontari</a>
                </div>
            <?php endwhile; ?>
        </div>

        <h2>Candidature in Attesa</h2>
        <div class="blocco1">
            <?php while ($c = $candidature->fetch_assoc()): ?>
                <p>
                    <strong><?= htmlspecialchars($c['nome']) ?></strong> si è candidato a
                    <strong><?= htmlspecialchars($c['titolo']) ?></strong>
                    <br>
                    <a class="btn" href="gestisci_candidature.php?id=<?= $c['id'] ?>&azione=accetta">✅ Accetta</a>
                    <a class="btn btn-danger" href="gestisci_candidature.php?id=<?= $c['id'] ?>&azione=rifiuta">❌ Rifiuta</a>
                </p>
            <?php endwhile; ?>
        </div>

        <h2>Volontari Accettati</h2>
        <div class="blocco1">
            <?php while ($a = $accettati->fetch_assoc()): ?>
                <p>✅ <?= htmlspecialchars($a['nome']) ?> → <?= htmlspecialchars($a['titolo']) ?></p>
            <?php endwhile; ?>
        </div>

        <h2>Volontari Compatibili (Matching)</h2>
        <div class="blocco1">
            <?php if ($matching->num_rows === 0): ?>
                <p>Nessun volontario compatibile trovato al momento.</p>
            <?php else: ?>
                <?php while ($m = $matching->fetch_assoc()): ?>
                    <p>
                        <strong><?= htmlspecialchars($m['nome']) ?></strong> è compatibile con
                        <strong><?= htmlspecialchars($m['titolo']) ?></strong>
                        <a class="btn" href="forza_candidature.php?id_volontario=<?= $m['id'] ?>&id_progetto=<?= $m['id_progetto'] ?>">📥 Invita/Iscrivi</a>
                    </p>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

        <h2>Report Ore Volontariato</h2>
        <div class="blocco1">
            <?php while ($r = $report->fetch_assoc()): ?>
                <p><strong><?= htmlspecialchars($r['titolo']) ?>:</strong> <?= $r['tot_ore'] ?> ore</p>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
