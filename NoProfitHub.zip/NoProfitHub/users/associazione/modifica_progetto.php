<?php
session_start();
require_once '../../db.php';

if ($_SESSION['tipo'] !== 'associazione') {
    header("Location: ../../login.php");
    exit();
}

$id = intval($_GET['id'] ?? 0);

// Verifica se il progetto appartiene all'associazione
$stmt = $conn->prepare("SELECT * FROM progetti WHERE id = ? AND id_associazione = ?");
$stmt->bind_param("ii", $id, $_SESSION['id']);
$stmt->execute();
$result = $stmt->get_result();
$progetto = $result->fetch_assoc();

if (!$progetto) {
    die("Progetto non trovato o accesso non autorizzato.");
}

// Ottieni tutte le competenze predefinite
$competenze_predefinite = $conn->query("SELECT * FROM competenze_predefinite")->fetch_all(MYSQLI_ASSOC);

// Ottieni le competenze già associate al progetto
$competenze_progetto = [];
$res = $conn->query("SELECT id_competenza FROM progetto_competenze WHERE id_progetto = $id");
while ($row = $res->fetch_assoc()) {
    $competenze_progetto[] = $row['id_competenza'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titolo = $_POST['titolo'];
    $descrizione = $_POST['descrizione'];
    $data_inizio = $_POST['data_inizio'];
    $data_fine = $_POST['data_fine'];
    $competenze_selezionate = $_POST['competenze_predefinite'] ?? [];

    // Aggiorna il progetto
    $stmt = $conn->prepare("UPDATE progetti SET titolo=?, descrizione=?, data_inizio=?, data_fine=? WHERE id=? AND id_associazione=?");
    $stmt->bind_param("ssssii", $titolo, $descrizione, $data_inizio, $data_fine, $id, $_SESSION['id']);
    $stmt->execute();

    // Rimuove le vecchie competenze
    $conn->query("DELETE FROM progetto_competenze WHERE id_progetto = $id");

    // Inserisce le nuove competenze (se presenti)
    if (!empty($competenze_selezionate)) {
        $stmt = $conn->prepare("INSERT INTO progetto_competenze (id_progetto, id_competenza) VALUES (?, ?)");
        foreach ($competenze_selezionate as $id_comp) {
            $id_comp = intval($id_comp);
            $stmt->bind_param("ii", $id, $id_comp);
            $stmt->execute();
        }
    }

    header("Location: associazione_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Modifica Progetto</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f3f7;
            padding: 30px;
        }

        .container {
            max-width: 750px;
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        h2 {
            color: #2c3e50;
            margin-bottom: 25px;
        }

        label {
            font-weight: bold;
            margin-top: 15px;
            display: block;
        }

        input[type="text"],
        input[type="date"],
        textarea {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 25px;
        }

        .checkbox-group label {
            background-color: #ecf0f1;
            padding: 8px 12px;
            border-radius: 6px;
            cursor: pointer;
            border: 1px solid #ccc;
        }

        .checkbox-group input[type="checkbox"] {
            margin-right: 6px;
        }

        button {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #219150;
        }

        .topbar {
            text-align: right;
            margin-bottom: 20px;
        }

        .topbar a {
            text-decoration: none;
            color: #2980b9;
            font-weight: bold;
        }

        .topbar a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="topbar">
            <a href="associazione_dashboard.php">← Torna alla dashboard</a>
        </div>

        <h2>Modifica Progetto</h2>

        <form method="POST">
            <label for="titolo">Titolo:</label>
            <input type="text" name="titolo" value="<?= htmlspecialchars($progetto['titolo']) ?>" required>

            <label for="descrizione">Descrizione:</label>
            <textarea name="descrizione" required><?= htmlspecialchars($progetto['descrizione']) ?></textarea>

            <label for="data_inizio">Data Inizio:</label>
            <input type="date" name="data_inizio" value="<?= $progetto['data_inizio'] ?>">

            <label for="data_fine">Data Fine:</label>
            <input type="date" name="data_fine" value="<?= $progetto['data_fine'] ?>">

            <label>Competenze Richieste:</label>
            <div class="checkbox-group">
                <?php foreach ($competenze_predefinite as $comp): ?>
                    <label>
                        <input type="checkbox" name="competenze_predefinite[]" value="<?= $comp['id'] ?>"
                            <?= in_array($comp['id'], $competenze_progetto) ? 'checked' : '' ?>>
                        <?= htmlspecialchars($comp['nome']) ?>
                    </label>
                <?php endforeach; ?>
            </div>

            <button type="submit">💾 Salva modifiche</button>
        </form>
    </div>
</body>
</html>
