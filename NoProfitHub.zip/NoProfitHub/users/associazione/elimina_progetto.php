<?php
session_start();
require_once '../../db.php';

if ($_SESSION['tipo'] !== 'associazione') {
    header("Location: ../../login.php");
    exit();
}

$id = $_GET['id'];

// Controlla se ci sono iscrizioni collegate
$stmt_check = $conn->prepare("SELECT COUNT(*) FROM iscrizioni WHERE id_progetto=?");
$stmt_check->bind_param("i", $id);
$stmt_check->execute();
$stmt_check->bind_result($num_iscrizioni);
$stmt_check->fetch();
$stmt_check->close();

if ($num_iscrizioni > 0 && !isset($_POST['conferma_eliminazione'])) {
    // Mostra conferma eliminazione
    echo '<form method="post">';
    echo '<p>Attenzione: ci sono ' . $num_iscrizioni . ' iscrizioni collegate a questo progetto. Sei sicuro di voler eliminare tutto?</p>';
    echo '<input type="hidden" name="conferma_eliminazione" value="1">';
    echo '<input type="submit" value="Conferma eliminazione">';
    echo ' <a href="associazione_dashboard.php">Annulla</a>';
    echo '</form>';
    exit();
}

// Se non ci sono iscrizioni o l'utente ha confermato, elimina tutto
$stmt1 = $conn->prepare("DELETE FROM iscrizioni WHERE id_progetto=?");
$stmt1->bind_param("i", $id);
$stmt1->execute();
$stmt1->close();

$stmt2 = $conn->prepare("DELETE FROM progetti WHERE id=? AND id_associazione=?");
$stmt2->bind_param("ii", $id, $_SESSION['id']);
$stmt2->execute();
$stmt2->close();

header("Location: associazione_dashboard.php");
exit();
