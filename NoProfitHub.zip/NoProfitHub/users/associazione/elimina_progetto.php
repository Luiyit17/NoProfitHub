<?php
session_start();
require_once '../../db.php';

if ($_SESSION['tipo'] !== 'associazione') {
    header("Location: ../../login.php");
    exit();
}

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM progetti WHERE id=? AND id_associazione=?");
$stmt->bind_param("ii", $id, $_SESSION['id']);
$stmt->execute();

header("Location: associazione_dashboard.php");
exit();
