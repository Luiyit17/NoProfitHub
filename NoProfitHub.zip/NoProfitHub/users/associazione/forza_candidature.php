<?php
session_start();
require_once '../../db.php';
if ($_SESSION['tipo'] !== 'associazione') exit();

$id_vol = intval($_GET['id_volontario']);
$id_proj = intval($_GET['id_progetto']);

$stmt = $conn->prepare("INSERT IGNORE INTO iscrizioni (id_volontario, id_progetto, stato) VALUES (?, ?, 'in_attesa')");
$stmt->bind_param("ii", $id_vol, $id_proj);
$stmt->execute();

header("Location: associazione_dashboard.php");
exit();
