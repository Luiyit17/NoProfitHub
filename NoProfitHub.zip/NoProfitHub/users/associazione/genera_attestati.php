<?php
require_once '../../db.php';
require_once '../../includes/auth_check.php';


if ($_SESSION['tipo'] !== 'associazione') {
    header("Location: ../login.php");
    exit();
}

$id_associazione = $_SESSION['id'];
$progetto_selezionato = isset($_GET['id_progetto']) ? intval($_GET['id_progetto']) : 0;

// Verifica che il progetto appartenga all'associazione
$stmt = $conn->prepare("SELECT titolo FROM progetti WHERE id = ? AND id_associazione = ?");
$stmt->bind_param("ii", $progetto_selezionato, $id_associazione);
$stmt->execute();
$stmt->bind_result($titolo_progetto);
if (!$stmt->fetch()) {
    echo "<script>alert('Progetto non trovato o non autorizzato.'); window.location.href = 'dashboard_associazione.php';</script>";
    exit();
}
$stmt->close();

// Recupera i volontari che hanno svolto almeno un turno
$sql = $conn->prepare("
    SELECT DISTINCT u.id, u.nome, u.email 
    FROM turni t
    JOIN utenti u ON t.id_volontario = u.id
    WHERE t.id_progetto = ?
");
$sql->bind_param("i", $progetto_selezionato);
$sql->execute();
$result_volontari = $sql->get_result();

// Gestione invio e generazione PDF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['volontario'], $_POST['descrizione'])) {
    $id_volontario = intval($_POST['volontario']);
    $descrizione = trim($_POST['descrizione']);

    // Verifica che il volontario abbia almeno un turno
    $check = $conn->prepare("SELECT COUNT(*) FROM turni WHERE id_progetto = ? AND id_volontario = ?");
    $check->bind_param("ii", $progetto_selezionato, $id_volontario);
    $check->execute();
    $check->bind_result($num_turni);
    $check->fetch();
    $check->close();

    if ($num_turni == 0) {
        echo "<script>alert('Il volontario selezionato non ha svolto alcun turno.'); window.location.href = 'genera_attestati.php?id_progetto=$progetto_selezionato';</script>";
        exit();
    }

    // Recupera dati volontario
    $volontario = $conn->prepare("SELECT nome, email FROM utenti WHERE id = ?");
    $volontario->bind_param("i", $id_volontario);
    $volontario->execute();
    $volontario->bind_result($nome_volontario, $email_volontario);
    $volontario->fetch();
    $volontario->close();

    // Genera PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Attestato di Partecipazione', 0, 1, 'C');
    $pdf->Ln(10);
    $pdf->SetFont('Arial', '', 12);
    $pdf->MultiCell(0, 10, "Si certifica che $nome_volontario ha partecipato al progetto \"$titolo_progetto\" svolgendo attività di volontariato.\n\nDescrizione: $descrizione\n\nData rilascio: " . date('d/m/Y'), 0, 'L');
    $file_path = "../../attestati/attestato_$id_progetto_$id_volontario.pdf";
    $pdf->Output('F', $file_path); // Salva il file

    // Inserisce l’attestato nel DB
    $stmt = $conn->prepare("INSERT INTO attestati (id_volontario, id_progetto, data_rilascio, descrizione) VALUES (?, ?, NOW(), ?)");
    $stmt->bind_param("iis", $id_volontario, $progetto_selezionato, $descrizione);
    $stmt->execute();

    // Invia email con allegato (semplice esempio)
    $subject = "Attestato di partecipazione - $titolo_progetto";
    $body = "Caro $nome_volontario,\nIn allegato trovi il tuo attestato di partecipazione al progetto \"$titolo_progetto\".\n\nGrazie per il tuo impegno!";
    $headers = "From: no-reply@noprofithub.org";

    // Attenzione: per inviare allegati serve usare PHPMailer o configurare MIME headers (qui semplificato)
    // Ti consiglio PHPMailer: https://github.com/PHPMailer/PHPMailer

    // Conferma
    echo "<script>alert('Attestato generato e salvato con successo!'); window.location.href = 'genera_attestati.php?id_progetto=$progetto_selezionato';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Genera Attestato</title>
    <style>
        body { font-family: Arial; padding: 20px; background-color: #f4f4f4; }
        form { background: white; padding: 20px; border-radius: 10px; width: 400px; margin: auto; }
        input, textarea, select, button { display: block; width: 100%; margin: 10px 0; padding: 8px; }
        button { background: #2ecc71; color: white; border: none; border-radius: 5px; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">Genera Attestato - <?php echo htmlspecialchars($titolo_progetto); ?></h2>
    <form method="POST">
        <label for="volontario">Volontario:</label>
        <select name="volontario" required>
            <option value="">-- Seleziona --</option>
            <?php while ($row = $result_volontari->fetch_assoc()): ?>
                <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['nome']); ?></option>
            <?php endwhile; ?>
        </select>

        <label for="descrizione">Descrizione Attività:</label>
        <textarea name="descrizione" rows="4" required placeholder="Es. Supporto nella distribuzione alimentare, accoglienza, organizzazione eventi..."></textarea>

        <button type="submit">Genera Attestato PDF</button>
        <a href="associazione_dashboard.php">Torna alla Dashboard</a>
    </form>
</body>
</html>
