<?php
require_once '../../db.php';
require_once '../../includes/auth_check.php';

if ($_SESSION['tipo'] != 'associazione') {
    header("Location: ../login.php");
    exit();
}

$id_associazione = $_SESSION['id'];

$successo = "";
$errore = "";

// Recupera id_progetto da GET o POST
$id_progetto = 0;
if (isset($_GET['id_progetto'])) {
    $id_progetto = intval($_GET['id_progetto']);
} elseif (isset($_POST['id_progetto'])) {
    $id_progetto = intval($_POST['id_progetto']);
}

// Ottieni i volontari iscritti SOLO al progetto selezionato
if ($id_progetto) {
    $volontari = $conn->query("
        SELECT u.id, u.nome
        FROM iscrizioni i
        JOIN utenti u ON i.id_volontario = u.id
        WHERE i.id_progetto = $id_progetto
        GROUP BY u.id
    ");
} else {
    // fallback: tutti i volontari dei progetti dell'associazione
    $volontari = $conn->query("
        SELECT u.id, u.nome
        FROM iscrizioni i
        JOIN utenti u ON i.id_volontario = u.id
        JOIN progetti p ON i.id_progetto = p.id
        WHERE p.id_associazione = $id_associazione
        GROUP BY u.id
    ");
}

// Se il form è stato inviato
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_volontario = intval($_POST['id_volontario']);
    $titolo = trim($_POST['titolo']);
    $descrizione = trim($_POST['descrizione']);

    // Controllo file caricato
    if (
        $id_volontario && $id_progetto && $titolo && $descrizione &&
        isset($_FILES['file_attestato']) && $_FILES['file_attestato']['error'] === UPLOAD_ERR_OK
    ) {
        $fileTmpPath = $_FILES['file_attestato']['tmp_name'];
        $fileName = $_FILES['file_attestato']['name'];
        $fileSize = $_FILES['file_attestato']['size'];
        $fileType = $_FILES['file_attestato']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        // Estensioni consentite
        $allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png'];
        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = uniqid('attestato_') . '.' . $fileExtension;
            $uploadFileDir = '../../uploads/attestati/';
            $dest_path = $uploadFileDir . $newFileName;

            // Crea cartella se non esiste
            if (!file_exists($uploadFileDir)) {
                mkdir($uploadFileDir, 0777, true);
            }

            // Sposta il file
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                // Salva nel database
                $stmt = $conn->prepare("INSERT INTO attestati (id_volontario, id_progetto, file_attestato, descrizione, data_rilascio) VALUES (?, ?, ?, ?, CURDATE())");
                $stmt->bind_param("iiss", $id_volontario, $id_progetto, $newFileName, $descrizione);

                if ($stmt->execute()) {
                    $successo = "Attestato rilasciato con successo!";
                } else {
                    $errore = "Errore durante l'inserimento nel database.";
                }
            } else {
                $errore = "Errore durante il salvataggio del file.";
            }
        } else {
            $errore = "Formato file non supportato. Sono ammessi: PDF, JPG, PNG.";
        }
    } else {
        $errore = "Tutti i campi sono obbligatori, incluso il file.";
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Rilascia Attestato</title>
    <style>
        body { font-family: Arial; background-color: #f2f2f2; padding: 30px; }
        .container { max-width: 600px; background: white; padding: 20px; border-radius: 8px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; }
        input, select, textarea { width: 100%; margin-top: 10px; padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
        .btn { margin-top: 15px; padding: 10px 15px; background-color: #2980b9; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background-color: #21618c; }
        .msg { margin-top: 15px; color: green; }
        .err { margin-top: 15px; color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Rilascia un Attestato</h2>

        <?php if ($successo): ?><p class="msg"><?php echo $successo; ?></p><?php endif; ?>
        <?php if ($errore): ?><p class="err"><?php echo $errore; ?></p><?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_progetto" value="<?php echo htmlspecialchars($id_progetto); ?>">
            <label for="id_volontario">Volontario:</label>
            <select name="id_volontario" required>
                <option value="">Seleziona un volontario</option>
                <?php while ($v = $volontari->fetch_assoc()): ?>
                    <option value="<?php echo $v['id']; ?>"><?php echo htmlspecialchars($v['nome']); ?></option>
                <?php endwhile; ?>
            </select>

            <label for="titolo">Titolo attestato:</label>
            <input type="text" name="titolo" required>

            <label for="descrizione">Descrizione:</label>
            <textarea name="descrizione" rows="4" required></textarea>

            <label for="file_attestato">File attestato (PDF, JPG, PNG):</label>
            <input type="file" name="file_attestato" accept=".pdf,.jpg,.jpeg,.png" required>

            <button type="submit" class="btn">Rilascia Attestato</button>
        </form>
        <button class="btn" style="background-color:#888; margin-top:10px;" onclick="window.history.back(); return false;">&larr; Indietro</button>
    </div>
</body>
</html>
