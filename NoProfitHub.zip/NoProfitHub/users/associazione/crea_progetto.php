<?php
session_start();
require_once '../../db.php';

if (!isset($_SESSION['id']) || $_SESSION['tipo'] !== 'associazione') {
    header("Location: ../login.php");
    exit();
}

$id_associazione = $_SESSION['id'];
$errore = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crea_progetto'])) {
    $titolo = trim($_POST['titolo']);
    $descrizione = trim($_POST['descrizione']);
    $data_inizio = $_POST['data_inizio'];
    $data_fine = $_POST['data_fine'];
    $competenze = $_POST['competenze'] ?? [];

    if ($data_fine <= $data_inizio) {
        $errore = "La data di fine deve essere successiva alla data di inizio.";
    } elseif (empty($titolo) || empty($descrizione)) {
        $errore = "Titolo e descrizione sono obbligatori.";
    } else {
        $stmt = $conn->prepare("INSERT INTO progetti (id_associazione, titolo, descrizione, data_inizio, data_fine) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $id_associazione, $titolo, $descrizione,  $data_inizio, $data_fine);

        if ($stmt->execute()) {
            $id_progetto = $conn->insert_id;

            // Inserisci competenze richieste per il progetto
            if (!empty($competenze)) {
                $stmt_comp = $conn->prepare("INSERT INTO progetto_competenze (id_progetto, id_competenza) VALUES (?, ?)");
                foreach ($competenze as $id_comp) {
                    $id_comp = intval($id_comp);
                    $stmt_comp->bind_param("ii", $id_progetto, $id_comp);
                    $stmt_comp->execute();
                }
                $stmt_comp->close();
            }

            header("Location: associazione_dashboard.php?success=1");
            exit();
        } else {
            $errore = "Errore durante la creazione del progetto.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Crea Progetto - NoProfitHub</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f6f9;
            padding: 20px;
        }
        .container {
            max-width: 700px;
            margin: auto;
            background-color: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        h2 {
            color: #2c3e50;
        }
        input[type="text"], input[type="date"], textarea {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        input[type="submit"] {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #219150;
        }
        .errore {
            color: red;
            margin-bottom: 15px;
        }
        .topbar {
            text-align: right;
            margin-bottom: 20px;
        }
        .checkbox-group label {
            margin-right: 10px;
            display: inline-block;
            cursor: pointer;
        }
    </style>
    <script>
    function validaDate() {
        let inizio = document.getElementById("data_inizio").value;
        let fine = document.getElementById("data_fine").value;

        if (fine <= inizio) {
            alert("La data di fine deve essere successiva a quella di inizio.");
            return false;
        }
        return true;
    }
    </script>
</head>
<body>
<div class="container">
    <div class="topbar">
        <a href="associazione_dashboard.php">← Torna alla dashboard</a>
    </div>
    <h2>Crea un nuovo progetto</h2>

    <?php if ($errore): ?>
        <div class="errore"><?php echo htmlspecialchars($errore); ?></div>
    <?php endif; ?>

    <form method="post" onsubmit="return validaDate();">
        <label for="titolo">Titolo:</label>
        <input type="text" id="titolo" name="titolo" required value="<?php echo isset($titolo) ? htmlspecialchars($titolo) : ''; ?>">

        <label for="descrizione">Descrizione:</label>
        <textarea id="descrizione" name="descrizione" rows="4" required><?php echo isset($descrizione) ? htmlspecialchars($descrizione) : ''; ?></textarea>

        <label for="data_inizio">Data inizio:</label>
        <input type="date" id="data_inizio" name="data_inizio" required value="<?php echo isset($data_inizio) ? htmlspecialchars($data_inizio) : ''; ?>">

        <label for="data_fine">Data fine:</label>
        <input type="date" id="data_fine" name="data_fine" required value="<?php echo isset($data_fine) ? htmlspecialchars($data_fine) : ''; ?>">

        <label>Competenze richieste (seleziona una o più):</label><br>
        <div class="checkbox-group">
            <?php
            $competenze_res = $conn->query("SELECT id, nome FROM competenze_predefinite");
            $selected_competenze = $_POST['competenze'] ?? [];
            while ($comp = $competenze_res->fetch_assoc()):
                $checked = in_array($comp['id'], $selected_competenze) ? 'checked' : '';
            ?>
                <label>
                    <input type="checkbox" name="competenze[]" value="<?php echo $comp['id']; ?>" <?php echo $checked; ?>>
                    <?php echo htmlspecialchars($comp['nome']); ?>
                </label>
            <?php endwhile; ?>
        </div>

        <br>
        <input type="submit" name="crea_progetto" value="Crea Progetto">
    </form>
</div>
</body>
</html>
