<?php
session_start();
require_once '../../db.php';
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] != 'associazione') {
	header("Location: ../login.php");
	exit();
}

if (!isset($_GET['id']) || !isset($_GET['azione'])) {
	header("Location: associazione_dashboard.php?error=missing_parameters");
	exit();
}

$id = intval($_GET['id']);
$azione = $_GET['azione'] == 'accetta' ? 'accettato' : 'rifiutato';
// Dopo aggiornamento stato...
// recupera dati volontario, associazione, progetto
mail($volontario_email, "Candidatura $stato", 
  "Ciao $volontario_nome,\n\nLa tua candidatura al progetto '$progetto_titolo' è stata $stato.\n\nNoProfitHub");


if (!$conn) {
	header("Location: associazione_dashboard.php?error=db_connection");
	exit();
}

$stmt = $conn->prepare("UPDATE iscrizioni SET stato=?,data_candidatura=NOW() WHERE id=?");
if ($stmt) {
	$stmt->bind_param("si", $azione, $id);
	$stmt->execute();
	$stmt->close();
}

header("Location: associazione_dashboard.php");
exit();
