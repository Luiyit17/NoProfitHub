<?php
session_start();
require_once '../../db.php';

if ($_SESSION['tipo'] !== 'associazione') {
    header("Location: ../../login.php");
    exit();
}


$id_progetto = $_GET['id'];
// Recupera il nome del progetto
$stmt_nome = $conn->prepare("SELECT titolo FROM progetti WHERE id = ?");
$stmt_nome->bind_param("i", $id_progetto);
$stmt_nome->execute();
$stmt_nome->bind_result($nome_progetto);
$stmt_nome->fetch();
$stmt_nome->close();

$stmt = $conn->prepare("
    SELECT u.nome, u.email, i.data_iscrizione
    FROM iscrizioni i
    JOIN utenti u ON i.id_volontario = u.id
    WHERE i.id_progetto = ?
");
$stmt->bind_param("i", $id_progetto);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Volontari Iscritti</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            padding: 32px 24px 24px 24px;
        }
        h2 {
            color: #2c3e50;
            margin-bottom: 24px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background: #f0f4f8;
            margin-bottom: 12px;
            padding: 12px 16px;
            border-radius: 5px;
        }
        .btn {
            display: inline-block;
            margin-top: 24px;
            padding: 10px 18px;
            background: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 16px;
            transition: background 0.2s;
        }
        .btn:hover {
            background: #217dbb;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Volontari iscritti al progetto "<?= htmlspecialchars($nome_progetto) ?>"</h2>
        <ul>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <li><strong><?= htmlspecialchars($row['nome']) ?></strong> (<?= htmlspecialchars($row['email']) ?>) - Iscritto il <?= htmlspecialchars($row['data_iscrizione']) ?></li>
            <?php endwhile; ?>
        </ul>
        <a class="btn" href="associazione_dashboard.php">⬅️ Torna alla dashboard</a>
    </div>
</body>
</html>
