<?php
session_start();
require_once '../../db.php';

if ($_SESSION['tipo'] !== 'associazione') {
    header("Location: ../../login.php");
    exit();
}

$id_progetto = $_GET['id'];

$stmt = $conn->prepare("
    SELECT u.nome, u.email, i.data_iscrizione
    FROM iscrizioni i
    JOIN utenti u ON i.id_volontario = u.id
    WHERE i.id_progetto = ?
");
$stmt->bind_param("i", $id_progetto);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Volontari Iscritti</title>
</head>
<body>
    <h2>Volontari iscritti al progetto #<?= $id_progetto ?></h2>
    <ul>
        <?php while ($row = $result->fetch_assoc()) : ?>
            <li><strong><?= $row['nome'] ?></strong> (<?= $row['email'] ?>) - Iscritto il <?= $row['data_iscrizione'] ?></li>
        <?php endwhile; ?>
    </ul>
    <a href="associazione_dashboard.php">⬅️ Torna alla dashboard</a>
</body>
</html>
