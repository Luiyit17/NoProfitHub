<?php
require_once '../../db.php';
session_start();

if (!isset($_SESSION['id']) || $_SESSION['tipo'] != 'associazione') {
    header("Location: ../login.php");
    exit();
}

$id_associazione = $_SESSION['id'];
$id_progetto = isset($_GET['id_progetto']) ? intval($_GET['id_progetto']) : 0;

// Verifica che il progetto appartenga all'associazione e prendi date inizio/fine
$check = $conn->prepare("SELECT id, titolo, data_inizio, data_fine FROM progetti WHERE id = ? AND id_associazione = ?");
$check->bind_param("ii", $id_progetto, $id_associazione);
$check->execute();
$check->bind_result($progetto_id, $progetto_titolo, $data_inizio, $data_fine);
$check->fetch();
$check->close();

if (!$progetto_id) {
    die("Progetto non trovato o non autorizzato.");
}

// Controlla se ci sono volontari accettati
$check = $conn->prepare("SELECT COUNT(*) FROM iscrizioni WHERE id_progetto = ? AND stato = 'accettato'");
$check->bind_param("i", $id_progetto);
$check->execute();
$check->bind_result($count);
$check->fetch();
$check->close();

if ($count == 0) {
    echo "<script>alert('Non ci sono volontari accettati per questo progetto.'); window.location.href = 'associazione_dashboard.php';</script>";
    exit();
}

// Volontari accettati
$volontari_result = $conn->query("
    SELECT u.id, u.nome, u.email 
    FROM iscrizioni i 
    JOIN utenti u ON i.id_volontario = u.id 
    WHERE i.id_progetto = $id_progetto AND i.stato = 'accettato'
");
// Funzione per convertire data in giorno della settimana (IT)
function getGiornoSettimana($data) {
    $giornoSettimanaEN = date('l', strtotime($data));
    $giorniIT = [
        'Monday'    => 'lun',
        'Tuesday'   => 'mar',
        'Wednesday' => 'mer',
        'Thursday'  => 'gio',
        'Friday'    => 'ven',
        'Saturday'  => 'sab',
        'Sunday'    => 'dom',
    ];
    return $giorniIT[$giornoSettimanaEN];}


// Fasce orarie disponibili
$fasce_orarie = ['Mattina', 'Pomeriggio', 'Sera'];

// Funzione per validare la fascia oraria
function isFasciaOrariaValida($fascia) {
    global $fasce_orarie;
    return in_array($fascia, $fasce_orarie);
}

// Verifica disponibilità del volontario
function volontarioDisponibile($conn, $id_volontario, $data, $fascia) {
    $giorno = getGiornoSettimana($data);

    $stmt = $conn->prepare("SELECT COUNT(*) FROM disponibilita_volontario WHERE id_volontario = ? AND giorno = ? AND fascia_oraria = ?");
    $stmt->bind_param("iss", $id_volontario, $giorno, $fascia);
    $stmt->execute();
    $count = 0;
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    return $count > 0;
}

// Aggiunta turno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['azione']) && $_POST['azione'] === 'aggiungi') {
    $data = $_POST['data_turno'];
    $fascia = $_POST['fascia_oraria'];
    $ore = intval($_POST['ore']);
    $id_volontario = intval($_POST['id_volontario']);

    // ✅ Validazione data, ore e fascia
    if ($data < $data_inizio || $data > $data_fine) {
        echo "<script>alert('La data del turno deve essere tra $data_inizio e $data_fine'); window.location.href = 'gestione_turni.php?id_progetto=$id_progetto';</script>";
        exit();
    }
    if ($ore < 1 || $ore > 8) {
        echo "<script>alert('Le ore devono essere tra 1 e 8.'); window.location.href = 'gestione_turni.php?id_progetto=$id_progetto';</script>";
        exit();
    }
    if (!isFasciaOrariaValida($fascia)) {
        echo "<script>alert('Fascia oraria non valida.'); window.location.href = 'gestione_turni.php?id_progetto=$id_progetto';</script>";
        exit();
    }

    // Verifica disponibilità volontario
    if (!volontarioDisponibile($conn, $id_volontario, $data, $fascia)) {
        echo "<script>alert('Il volontario non è disponibile in quel giorno e fascia oraria!'); window.location.href = 'gestione_turni.php?id_progetto=$id_progetto';</script>";
        exit();
    }

    $res = $conn->prepare("SELECT email FROM utenti WHERE id = ?");
    $res->bind_param("i", $id_volontario);
    $res->execute();
    $res->bind_result($volontario_email);
    $res->fetch();
    $res->close();

    $stmt = $conn->prepare("INSERT INTO turni (id_progetto, id_volontario, data_turno, fascia_oraria, ore) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iissi", $id_progetto, $id_volontario, $data, $fascia, $ore);
    $stmt->execute();

    /*mail($volontario_email, "Assegnazione turno - NoProfitHub", 
        "Sei stato assegnato al turno del $data per il progetto \"$progetto_titolo\".");*/
}

// Modifica turno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['azione'] === 'modifica') {
    $id_turno = intval($_POST['id_turno']);
    $data = $_POST['data_turno'];
    $fascia = $_POST['fascia_oraria'];
    $ore = intval($_POST['ore']);
    $id_volontario = intval($_POST['id_volontario']);

    // ✅ Validazione data, ore e fascia
    if ($data < $data_inizio || $data > $data_fine) {
        echo "<script>alert('La data del turno deve essere tra $data_inizio e $data_fine'); window.history.back();</script>";
        exit();
    }
    if ($ore < 1 || $ore > 8) {
        echo "<script>alert('Le ore devono essere tra 1 e 8.'); window.history.back();</script>";
        exit();
    }
    if (!isFasciaOrariaValida($fascia)) {
        echo "<script>alert('Fascia oraria non valida.'); window.history.back();</script>";
        exit();
    }

    // Verifica disponibilità volontario
    if (!volontarioDisponibile($conn, $id_volontario, $data, $fascia)) {
        echo "<script>alert('Il volontario non è disponibile in quel giorno e fascia oraria!'); window.history.back();</script>";
        exit();
    }

    $res = $conn->prepare("SELECT email FROM utenti WHERE id = ?");
    $res->bind_param("i", $id_volontario);
    $res->execute();
    $res->bind_result($volontario_email);
    $res->fetch();
    $res->close();

    $stmt = $conn->prepare("UPDATE turni SET data_turno = ?, fascia_oraria = ?, ore = ?, id_volontario = ? WHERE id = ? AND id_progetto = ?");
    $stmt->bind_param("ssiiii", $data, $fascia, $ore, $id_volontario, $id_turno, $id_progetto);
    $stmt->execute();

   /* mail($volontario_email, "Modifica turno - NoProfitHub", 
        "Il tuo turno per il progetto \"$progetto_titolo\" è stato aggiornato al $data.");*/
}

// Cancella turno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['azione'] === 'cancella') {
    $id_turno = intval($_POST['id_turno']);

    $res = $conn->prepare("SELECT u.email FROM turni t JOIN utenti u ON t.id_volontario = u.id WHERE t.id = ?");
    $res->bind_param("i", $id_turno);
    $res->execute();
    $res->bind_result($volontario_email);
    $res->fetch();
    $res->close();

    $stmt = $conn->prepare("DELETE FROM turni WHERE id = ? AND id_progetto = ?");
    $stmt->bind_param("ii", $id_turno, $id_progetto);
    $stmt->execute();

    /*mail($volontario_email, "Cancellazione turno - NoProfitHub", 
        "Il tuo turno per il progetto \"$progetto_titolo\" è stato cancellato.");*/
}

$turni = $conn->query("
    SELECT t.*, u.nome AS nome_volontario 
    FROM turni t 
    LEFT JOIN utenti u ON t.id_volontario = u.id 
    WHERE t.id_progetto = $id_progetto 
    ORDER BY t.data_turno ASC
");
?>

<!-- PARTE HTML -->





<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Gestione Turni - NoProfitHub</title>
    <style>
        body { font-family: Arial; padding: 20px; background-color: #f2f2f2; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        form { margin-top: 30px; background: #fff; padding: 20px; border-radius: 8px; }
        input, select { padding: 8px; margin: 5px; }
        .btn { padding: 8px 12px; background-color: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background-color: #2980b9; }
    </style>
</head>
<body>

<h2>Gestione Turni - <?php echo htmlspecialchars($progetto_titolo); ?></h2>

<h3>Turni esistenti</h3>
<table>
    <tr>
<th>Data</th>
<th>Fascia oraria</th>
<th>Ore</th>
<th>Volontario</th>
<th>Azioni</th>
    </tr>
    <?php while ($row = $turni->fetch_assoc()): ?>
        <tr>
            <form method="POST">
                <input type="hidden" name="azione" value="modifica">
                <input type="hidden" name="id_turno" value="<?php echo $row['id']; ?>">
<td><input type="date" name="data_turno" value="<?php echo $row['data_turno']; ?>"></td>
<td>
    <select name="fascia_oraria">
        <?php foreach ($fasce_orarie as $fascia): ?>
            <option value="<?php echo $fascia; ?>" <?php if ($fascia == $row['fascia_oraria']) echo 'selected'; ?>><?php echo $fascia; ?></option>
        <?php endforeach; ?>
    </select>
</td>
<td><input type="number" name="ore" value="<?php echo $row['ore']; ?>"></td>
<td>
    <select name="id_volontario">
        <?php
        $volontari_result->data_seek(0);
        while ($v = $volontari_result->fetch_assoc()):
        ?>
            <option value="<?php echo $v['id']; ?>" <?php if ($v['id'] == $row['id_volontario']) echo 'selected'; ?>>
                <?php echo htmlspecialchars($v['nome']); ?>
            </option>
        <?php endwhile; ?>
    </select>
</td>
                <td>
                    <button class="btn" type="submit">Salva</button>
            </form>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="azione" value="cancella">
                <input type="hidden" name="id_turno" value="<?php echo $row['id']; ?>">
                <button class="btn" type="submit" style="background-color:red;">Elimina</button>
            </form>
                </td>
        </tr>
    <?php endwhile; ?>
</table>

<h3>Aggiungi Turno</h3>
<form method="POST">
    <input type="hidden" name="azione" value="aggiungi">
    <label>Data: <input type="date" name="data_turno" required min="<?php echo $data_inizio; ?>" max="<?php echo $data_fine; ?>"></label>
    <label>Fascia oraria:
        <select name="fascia_oraria" required>
            <?php foreach ($fasce_orarie as $fascia): ?>
                <option value="<?php echo $fascia; ?>"><?php echo $fascia; ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Ore:<input type="number" name="ore" min="1" max="8" required></label>
    <label>Volontario:
        <select name="id_volontario" required>
            <?php
            $volontari_result->data_seek(0);
            while ($v = $volontari_result->fetch_assoc()):
            ?>
                <option value="<?php echo $v['id']; ?>"><?php echo htmlspecialchars($v['nome']); ?></option>
            <?php endwhile; ?>
        </select>
    </label>
    <button class="btn" type="submit">Aggiungi</button>
</form>
<a class="btn" href="associazione_dashboard.php">Indietro</a>
</body>
</html>
