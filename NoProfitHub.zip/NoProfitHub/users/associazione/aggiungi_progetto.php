<?php
require_once '../../db.php';
session_start();

if (!isset($_SESSION['id']) || $_SESSION['tipo'] != 'associazione') {
    header("Location: ../login.php");
    exit();
}

$id_associazione = $_SESSION['id'];
$id_progetto = isset($_GET['id_progetto']) ? intval($_GET['id_progetto']) : 0;

// Verifica progetto dell'associazione
$stmt = $conn->prepare("SELECT titolo FROM progetti WHERE id = ? AND id_associazione = ?");
$stmt->bind_param("ii", $id_progetto, $id_associazione);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($progetto_titolo);
if ($stmt->num_rows === 0) {
    die("Progetto non trovato o non autorizzato.");
}
$stmt->fetch();

// Verifica che ci siano volontari
$check = $conn->prepare("SELECT id FROM iscrizioni WHERE id_progetto = ? LIMIT 1");
$check->bind_param("i", $id_progetto);
$check->execute();
$check->store_result();
if ($check->num_rows === 0) {
    echo "<script>alert('Non ci sono volontari iscritti a questo progetto.'); window.location.href = 'dashboard_associazione.php';</script>";
    exit();
}

// Elenco volontari candidati
$volontari_result = $conn->query("
    SELECT u.id, u.nome, u.email 
    FROM iscrizioni i 
    JOIN utenti u ON i.id_volontario = u.id 
    WHERE i.id_progetto = $id_progetto
");

// Mappa ID volontario → email
$volontari_email = [];
$volontari_result->data_seek(0);
while ($v = $volontari_result->fetch_assoc()) {
    $volontari_email[$v['id']] = $v['email'];
}

// Aggiungi turno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['azione'] === 'aggiungi') {
    $data = $_POST['data_turno'];
    $ore = intval($_POST['ore']);
    $id_volontario = intval($_POST['id_volontario']);

    $stmt = $conn->prepare("INSERT INTO turni (id_progetto, id_volontario, data_turno, ore) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iisi", $id_progetto, $id_volontario, $data, $ore);
    $stmt->execute();

    $volontario_email = $volontari_email[$id_volontario] ?? null;
    if ($volontario_email) {
        mail($volontario_email, "Nuovo turno assegnato",
            "Sei stato assegnato al turno del $data per il progetto '$progetto_titolo'.");
    }
}

// Modifica turno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['azione'] === 'modifica') {
    $id_turno = intval($_POST['id_turno']);
    $data = $_POST['data_turno'];
    $ore = intval($_POST['ore']);
    $id_volontario = intval($_POST['id_volontario']);

    $stmt = $conn->prepare("UPDATE turni SET data_turno = ?, ore = ?, id_volontario = ? WHERE id = ? AND id_progetto = ?");
    $stmt->bind_param("siiii", $data, $ore, $id_volontario, $id_turno, $id_progetto);
    $stmt->execute();

    $volontario_email = $volontari_email[$id_volontario] ?? null;
    if ($volontario_email) {
        mail($volontario_email, "Modifica turno",
            "Il tuo turno è stato modificato: nuova data $data per il progetto '$progetto_titolo'.");
    }
}

// Cancella turno
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['azione'] === 'cancella') {
    $id_turno = intval($_POST['id_turno']);

    // Recupera email prima di cancellare
    $stmt = $conn->prepare("
        SELECT u.email 
        FROM turni t 
        JOIN utenti u ON t.id_volontario = u.id 
        WHERE t.id = ? AND t.id_progetto = ?
    ");
    $stmt->bind_param("ii", $id_turno, $id_progetto);
    $stmt->execute();
    $stmt->bind_result($volontario_email);
    $stmt->fetch();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM turni WHERE id = ? AND id_progetto = ?");
    $stmt->bind_param("ii", $id_turno, $id_progetto);
    $stmt->execute();

    if ($volontario_email) {
        mail($volontario_email, "Turno cancellato", "Il tuo turno per il progetto '$progetto_titolo' è stato cancellato.");
    }
}

// Carica tutti i turni per il progetto
$turni = $conn->query("
    SELECT t.*, u.nome AS nome_volontario 
    FROM turni t 
    LEFT JOIN utenti u ON t.id_volontario = u.id 
    WHERE t.id_progetto = $id_progetto 
    ORDER BY t.data_turno ASC
");
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Aggiungi Progetto</title>
</head>
<body>
    <h2>Nuovo Progetto</h2>
    <form method="POST">
        <label>Titolo:</label><br>
        <input type="text" name="titolo" required><br><br>

        <label>Descrizione:</label><br>
        <textarea name="descrizione" required></textarea><br><br>

        <label>Requisiti:</label><br>
        <textarea name="requisiti"></textarea><br><br>

        <label>Data Inizio:</label><br>
        <input type="date" name="data_inizio"><br><br>

        <label>Data Fine:</label><br>
        <input type="date" name="data_fine"><br><br>

        <button type="submit">Crea</button>
    </form>
</body>
</html>
