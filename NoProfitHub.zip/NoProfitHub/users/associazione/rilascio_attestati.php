<?php
require_once '../../db.php';
require_once '../../includes/auth_check.php';

if ($_SESSION['tipo'] != 'associazione') {
    header("Location: ../login.php");
    exit();
}

$id_associazione = $_SESSION['id'];
$successo = "";
$errore = "";

// Ottieni i volontari iscritti ai progetti dell'associazione
$volontari = $conn->query("
    SELECT u.id, u.nome
    FROM iscrizioni i
    JOIN utenti u ON i.id_volontario = u.id
    JOIN progetti p ON i.id_progetto = p.id
    WHERE p.id_associazione = $id_associazione
    GROUP BY u.id
");

// Se il form è stato inviato
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_volontario = intval($_POST['id_volontario']);
    $titolo = trim($_POST['titolo']);
    $descrizione = trim($_POST['descrizione']);

    if ($id_volontario && $titolo && $descrizione) {
        $stmt = $conn->prepare("INSERT INTO attestati (id_volontario, titolo, descrizione, data_rilascio) VALUES (?, ?, ?, CURDATE())");
        $stmt->bind_param("iss", $id_volontario, $titolo, $descrizione);
        if ($stmt->execute()) {
            $successo = "Attestato rilasciato con successo!";
        } else {
            $errore = "Errore durante il rilascio dell'attestato.";
        }
    } else {
        $errore = "Tutti i campi sono obbligatori.";
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Rilascia Attestato</title>
    <style>
        body { font-family: Arial; background-color: #f2f2f2; padding: 30px; }
        .container { max-width: 600px; background: white; padding: 20px; border-radius: 8px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; }
        input, select, textarea { width: 100%; margin-top: 10px; padding: 8px; border-radius: 5px; border: 1px solid #ccc; }
        .btn { margin-top: 15px; padding: 10px 15px; background-color: #2980b9; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background-color: #21618c; }
        .msg { margin-top: 15px; color: green; }
        .err { margin-top: 15px; color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Rilascia un Attestato</h2>

        <?php if ($successo): ?><p class="msg"><?php echo $successo; ?></p><?php endif; ?>
        <?php if ($errore): ?><p class="err"><?php echo $errore; ?></p><?php endif; ?>

        <form method="POST">
            <label for="id_volontario">Volontario:</label>
            <select name="id_volontario" required>
                <option value="">Seleziona un volontario</option>
                <?php while ($v = $volontari->fetch_assoc()): ?>
                    <option value="<?php echo $v['id']; ?>"><?php echo htmlspecialchars($v['nome']); ?></option>
                <?php endwhile; ?>
            </select>

            <label for="titolo">Titolo attestato:</label>
            <input type="text" name="titolo" required>

            <label for="descrizione">Descrizione:</label>
            <textarea name="descrizione" rows="4" required></textarea>

            <button type="submit" class="btn">Rilascia Attestato</button>
        </form>
    </div>
</body>
</html>
