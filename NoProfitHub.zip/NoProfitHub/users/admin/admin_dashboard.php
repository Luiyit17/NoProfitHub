<?php
require_once '../../db.php';
require_once '../../includes/auth_check.php';

if ($_SESSION['tipo'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Statistiche generali
$totaleProgetti = $conn->query("SELECT COUNT(*) AS tot FROM progetti")->fetch_assoc()['tot'];
$totaleVolontari = $conn->query("SELECT COUNT(*) AS tot FROM utenti WHERE tipo = 'volontario'")->fetch_assoc()['tot'];
$totaleAssociazioni = $conn->query("SELECT COUNT(*) AS tot FROM utenti WHERE tipo = 'associazione'")->fetch_assoc()['tot'];
$oreTotali = $conn->query("SELECT SUM(ore) AS tot FROM turni")->fetch_assoc()['tot'] ?? 0;

// Top 5 associazioni per numero progetti
$topAssociazioni = $conn->query("
    SELECT u.nome, COUNT(p.id) AS num_progetti
    FROM utenti u
    JOIN progetti p ON u.id = p.id_associazione
    GROUP BY u.id
    ORDER BY num_progetti DESC
    LIMIT 5
");

// Top 5 volontari per ore di volontariato
$topVolontari = $conn->query("
    SELECT u.nome, SUM(t.ore) AS ore_totali
    FROM utenti u
    JOIN turni t ON u.id = t.id_volontario
    WHERE u.tipo = 'volontario'
    GROUP BY u.id
    ORDER BY ore_totali DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Amministratore - NoProfitHub</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fa;
            padding: 20px;
        }
        .stat-box, .section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 0 8px rgba(0,0,0,0.05);
        }
        h1, h2 {
            color: #2c3e50;
        }
        .stat-grid {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        }
        .stat-item {
            flex: 1 1 200px;
            background: #ecf0f1;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }
        .stat-item h3 {
            margin: 0;
            color: #2980b9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #2980b9;
            color: white;
        }
        .logout {
            text-align: right;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <div class="logout">
        <a href="../../logout.php">Esci</a>
    </div>

    <h1>Dashboard Amministratore</h1>

    <div class="stat-box">
        <h2>Statistiche Generali</h2>
        <div class="stat-grid">
            <div class="stat-item">
                <h3><?php echo $totaleProgetti; ?></h3>
                <p>Progetti Totali</p>
            </div>
            <div class="stat-item">
                <h3><?php echo $totaleVolontari; ?></h3>
                <p>Volontari</p>
            </div>
            <div class="stat-item">
                <h3><?php echo $totaleAssociazioni; ?></h3>
                <p>Associazioni</p>
            </div>
            <div class="stat-item">
                <h3><?php echo $oreTotali; ?></h3>
                <p>Ore Volontariato</p>
            </div>
        </div>
    </div>

    <div class="section">
        <h2>Top 5 Associazioni per Numero di Progetti</h2>
        <table>
            <tr>
                <th>Associazione</th>
                <th>Numero Progetti</th>
            </tr>
            <?php while ($row = $topAssociazioni->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['nome']); ?></td>
                    <td><?php echo $row['num_progetti']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <div class="section">
        <h2>Top 5 Volontari per Ore Totali</h2>
        <table>
            <tr>
                <th>Volontario</th>
                <th>Ore Totali</th>
            </tr>
            <?php while ($row = $topVolontari->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['nome']); ?></td>
                    <td><?php echo $row['ore_totali']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

</body>
</html>
